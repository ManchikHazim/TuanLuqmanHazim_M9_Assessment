<?php
require __DIR__ . '/vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

$client_id = $_ENV['CLIENT_ID'] ?? null;
$client_secret = $_ENV['CLIENT_SECRET'] ?? null;

if (!$client_id || !$client_secret) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(["error" => "Client ID or Client Secret is not set."]);
    exit;
}

header('Content-Type: application/json');
echo json_encode([
    "client_id" => $client_id,
    "client_secret" => $client_secret
]);
?>
