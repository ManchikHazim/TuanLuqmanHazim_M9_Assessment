<!DOCTYPE html>
<html>
<head>
<style>
  button {
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 5px;
  }
  p {
    font-family: Arial, sans-serif;
    font-size: 18px;
    margin-top: 20px;
  }
</style>

<script>
function myFunction() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("demo").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "M9_no6_ajaxcall.php", true);
  xhttp.send();
}
</script>
</head>
<body>

<button onclick="myFunction()">Click Me</button>

<p id="demo"></p>

</body>
</html>