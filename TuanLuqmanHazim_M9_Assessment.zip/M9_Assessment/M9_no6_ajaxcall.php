<?php
echo "Hello i am Tuan Luqman Hazim!";
?>