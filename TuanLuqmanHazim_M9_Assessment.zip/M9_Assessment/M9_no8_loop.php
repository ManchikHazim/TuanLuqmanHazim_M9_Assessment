<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diamond Shape</title>
</head>
<body>

<?php

// Calculate the number of rows (adjust as needed)
$numRows = 8; 

// Loop through each row
for ($i = 1; $i <= $numRows; $i++) {
    // Calculate the number of asterisks in the current row
    $asterisks = min($i, $numRows - $i + 1); 

    // Print asterisks
    for ($j = 0; $j < $asterisks; $j++) {
        echo "*";
    }

    // Print a newline after each row
    echo "<br>"; 
}

?>

</body>
</html>